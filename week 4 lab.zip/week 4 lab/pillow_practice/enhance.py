from PIL import Image, ImageEnhance

# import an image 
image = Image.open('/Users/bishotanagarkoti/Downloads/Week_4_Lab_Activities/Assets/Insects/1_Gammar 2021_1_2021_06_03-13-19-23-879.PNG')

# create an enhancer
vibrance_enhancer = ImageEnhance.Color(image)
contrast_enhancer = ImageEnhance.Contrast(image)
brightness_enhancer = ImageEnhance.Brightness(image)
sharpness_enhancer = ImageEnhance.Sharpness(image)

# apply the enhancer 
enhanced_image = sharpness_enhancer.enhance(1.5)

# show 
image.show()
enhanced_image.show()