from PIL import Image

file_name = '/Users/bishotanagarkoti/Downloads/Week_4_Lab_Activities/Assets/Insects/2_Sphaer 2021_1_2021_06_03-11-22-54-852.PNG'
image = Image.open(file_name)

img_rotated = image.rotate(30)
img_rotated.save('/Users/bishotanagarkoti/Downloads/Week_4_Lab_Activities/Assets/Insects/sphaer_rotated.png', 'JPEG')
# analyze the image 
print(image.size)
print(image.filename)
print(image.format)
# show the image
img_rotated.show()

