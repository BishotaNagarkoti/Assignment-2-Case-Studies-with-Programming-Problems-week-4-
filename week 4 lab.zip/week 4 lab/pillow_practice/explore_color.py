from PIL import Image

image = Image.open('/Users/bishotanagarkoti/Downloads/Week_4_Lab_Activities/Assets/Insects/1_Limniu 2021_1_2021_06_02-13-08-37-958.PNG')

# get one pixel
print(image.getpixel((0, 0)))

# explore and change pixels
for x in range(image.size[0]):
    for y in range(image.size[1]):
        if image.getpixel((x, y))[0] == 0:
            image.putpixel((x, y), (200, 20, 20))

image.show()